<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\View;
class TourPackageController extends Controller
{
    //
    public function viewHotelRoomType(Request $request){
        $room_type = json_decode($request->get('room_type'));

        $view = View::make(
            'component.item_hotel_room_type',
            [
                'room_type'   => $room_type
            ]
        );

        $contents = $view->render();

        return response()->json($contents);
    }

    public function store(Request $request)
    {
        $this->validateTourPackage($request);

        $service_id = $request->serviceId;
        $bus_id = $request->get('bus_id', null);
        $drivers_id = $request->get('drivers_id', null);
        $dep_date_transfer = $request->get('dep_date_transfer', null);
        $ret_date_transfer = $request->get('ret_date_transfer', null);
        $package_id = $request->get('package_id', null);
        $tourId = $request->tourId;
        $defaultHotel = $this->getDefaultTimes('hotel');
        $defaultService = $this->getDefaultTimes('service');
        $defaultTransfer = $this->getDefaultTimes('transfer');


        // validate Transfer dates
        if (strtolower($request->serviceType) == 'transfer') {
            // validate buses
            $res_bus_validate = $this->busDayHelper->validateBuses($bus_id,
                $dep_date_transfer,
                $ret_date_transfer);

            if(!$res_bus_validate['check']){
                $data = [
                    'bus_busy' => true,
                    'bus_busy_message' => 'The Bus is Busy from ' . $res_bus_validate['start'] . ' to ' . $res_bus_validate['end']
                ];

                return response()->json($data);
            }

            //validate drivers
            $res_driver_validate = $this->busDayHelper->validateDrivers($drivers_id, $dep_date_transfer, $ret_date_transfer);

            if(!$res_driver_validate){
                $data = [
                    'bus_busy' => true,
                    'bus_busy_message' => 'The Driver is Busy'
                ];

                return response()->json($data);
            }
        }





        if(strtolower($request->serviceType) == 'cruises'){
            $request->serviceType = 'cruise';
        }

        $default_status_service = Status::query()
            ->where('type', 'service_in_tour')
            ->where('name', 'Pending')->first();

        $default_status_hotel = Status::query()
            ->where('type', 'hotel')
            ->where('name', 'Pending')->first();

        $default_status_transfer = Status::query()
            ->where('type', 'bus')
            ->where('name', 'Planned, need to check with coach co')->first();

        $status = null;

        $currency = Currencies::query()->where('name', 'Euro')->first();
        $tourPackage = new TourPackage();
        $tourPackage->type = array_search(strtolower($request->serviceType), $this->serviceTypes);
        $tourPackage->reference = $request->serviceId;
        $tourPackage->name = $request->serviceName;
        $tourPackage->paid = $request->paid ?: false;
        if(strtolower($request->serviceType) == 'hotel'){
            $status = $default_status_hotel ? $default_status_hotel->id : null;
        }else if(strtolower($request->serviceType) == 'transfer'){
            $status = $default_status_transfer ? $default_status_transfer->id : null;
        }else{
            $status = $default_status_service ? $default_status_service->id : null;
        }
        $tourPackage->status = $status;
        $tourPackage->total_amount = $request->total_amount ?: 0;
        $tourPackage->currency = $currency != null ? $currency->id : null;
        $tourPackage->rate = $request->rate;
        $tourPackage->note = $request->note;
        $tourPackage->description = $request->description;

        $serviceType = $request->serviceType; // we should to connect with tourday or tour(transfer)
        if (strtolower($serviceType) == 'transfer') {
            $tourId = $request->tourId;
            $tour = Tour::findOrFail($tourId);
            $tourPackage->time_from = $dep_date_transfer.' '.$defaultTransfer['time_from'];
        }
        else {
            $tourDay = TourDay::query()->get()->where('id', $request->tourDayId)->first();
            $tourDay_ = $tourDay;
            $tourId = $tourDay->tour;
            $tour = $this->tourRepository->byId($tourId);

            if($request->pageService == 'change_edit_service'){
                $tourPackage->time_from = $request->serviceOldTime;
            }else{

                if(strtolower($serviceType) == 'hotel') {
                    $time = $defaultHotel['time_from'];
                }else {
                    $time = $defaultService['time_from'];
                }

                $tourPackage->time_from = $request->serviceOldTime == null ? $tourDay->date . ' '. $time :  $tourDay->date . ' ' . $request->serviceOldTime;
            }
        }

        $tourPackage->pax = $tour->pax;

        if(strtolower($serviceType) == 'hotel'){
            $tourPackage->time_to = !empty($request->tourDayIdRetirement) ? $request->tourDayIdRetirement.' '.$defaultHotel['time_to'] : $tourPackage->time_from;
        }
        else{
            if (strtolower($serviceType) == 'transfer') {
                $tourPackage->time_to = $ret_date_transfer.' '.$defaultTransfer['time_to'];
            }
            else if($tourPackage->time_from) {
                //$timeFromDate = Carbon::createFromFormat('Y-m-d H:i:s', $tourPackage->time_from)->addHour();
                $timeFromDate = (new Carbon($tourPackage->time_from));
                $timeFromDate->format('Y-m-d H:i:s');
                $timeFromDate->addHour();
                $tourPackage->time_to = $timeFromDate;
            }



        }
        $tourPackage->pax_free = $tour->pax_free;
        $tourPackage->driver_id = $request->get('driver_id', null);
        $tourPackage->save();

        if (strtolower($serviceType) != 'transfer') {
            $tourPackage->assignTourDay($tourDay);
            if(strtolower($request->serviceType) == 'hotel') {
                $this->createHotelPackages($tourPackage, $tourDay->tour, $request->tourDayIdRetirement);
            }
        } else {
            $tourPackage->tour_id = $request->tourId;
            $tourPackage->save();
        }
        $this->tourPackageRepository->setCityTaxInPackage($tourPackage);

        if (strtolower($serviceType) == 'transfer'){

            DB::beginTransaction();

            $dates_interval = $this->busDayHelper->getDatesInterval($dep_date_transfer, $ret_date_transfer);


            foreach ($dates_interval as $tourDay){
                $busDay = new BusDay();
                $busDay->tour_id = $tourId;
                $busDay->transfer_id = $service_id;
                $busDay->tour_package_id = $tourPackage->id;
                $busDay->date = $tourDay['date'];
                $busDay->status_id = $default_status_transfer ? $default_status_transfer->id : null;
                $busDay->bus_id = $bus_id;
                $busDay->name_trip = null;
                $busDay->city_trip = null;
                $busDay->country_trip = null;
                $busDay->save();

                $this->busDayHelper->addDriversToTransfer($drivers_id, $tour->id, $service_id, $tourPackage->id, $busDay->id);
            }

            DB::commit();
        }


        if (strtolower($request->serviceType) == 'hotel') {
            $records = TourRoomTypeHotel::query()->where('tour_id', $request->tourId)->get();
            foreach ($records as $record) {
                $price_hotel = PricesRoomTypeHotel::query()
                    ->where('hotel_id', $tourPackage->reference)
                    ->where('room_type_id', $record->room_type_id)->first();

                $create_record = new HotelRoomTypes();
                $create_record->room_type_id = $record->room_type_id;
                $create_record->tour_package_id = $tourPackage->id;
                $create_record->count = $record->count;
                $create_record->price = $price_hotel ? $price_hotel->price : 0;
                $create_record->save();
                
                $price = $this->checkPriceBySeasons($create_record, $tourPackage, $tourDay_);
            }
        }

        $tour->price_for_one =  $tour->getPriceForOnePaxInTour();
        $tour->save();



        $this->logActivity($tourPackage, $tour);
        if($request->pageService == 'change_edit_service'){
            return response('/tour_package/'.$tourPackage->id.'/edit');
        }

        if ($request->ajax()) return response(route('tour.show', ['id' => $tourId]));
        return redirect(route('tour.edit', ['id' => $tourId]));
    }

}
