<!DOCTYPE html>
<html lang="en">
  @include('TMSClient.layout.head')
  <body>
    <div class="main">
      <div class="main-content">
        <section class="register">
          <div class="container-fluid">
            <div class="row">
              <div class="col-lg-7">
                <div class="wrapper">
                  <div>
                    <h1 class="title text-center">Login to your account</h1>
					   @if(session('error'))
                                    <div class="alert alert-danger">{{ session('error') }}</div>
                                    @endif
                    <form action="{{ route('client.login') }}" method="post">
                 		{{csrf_field()}}
                      <div class="d-flex flex-column align-items-center w-100">
                        <div class="input-wrapper">
                          <input type="text" class="form-control" placeholder="Email Address" name = "contact_email">
                        </div>
                        <div class="input-wrapper">
                          <input type="password" class="form-control" placeholder="Password" name = "password">
                        </div>
                        <button class="btn btn-primary px-lg-5" type="submit">Login</button>
                      </div>
                     
                    </form>
                  </div>
                </div>
              </div>
              <div class="col-lg-5 p-0 d-none d-lg-flex">
                <div class="register-img">
                  <div class="d-flex align-items-center justify-content-center flex-column h-100 w-100 position-relative">
                    <h1 class="title text-white">New here?</h1>
                    <p class="text text-white text-center px-3 px-lg-5 ">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Obcaecati temporibus nobis maiores.</p>
                    <a href="" class="btn btn-primary px-lg-5">Sign up</a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>

      <div class="cursor"></div>
    </div>

    @include('TMSClient.layout.footer')
  </body>
</html>
