<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="{{asset('clientassets/css/bootstrap.min.css')}}" />
    <link rel="stylesheet" href="{{asset('clientassets/css/slick.css')}}" />
    <link rel="stylesheet" href="{{asset('clientassets/css/slick-theme.css')}}" />
    <link rel="stylesheet" href="{{asset('clientassets/fonts/fontawesome-free-5.15.4-web/css/all.css')}}" />
    <link rel="stylesheet" href="{{asset('clientassets/scss/style.css')}}" />


    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/jquery-form-wizard@3.2.0/dist/jquery.formwizard.min.css" />
	<meta name="csrf-token" content="{{ csrf_token() }}">
	 <link rel="stylesheet" type="text/css" href="{{asset('css/datatables.min.css')}}"/>
    <title>TMS - Client</title>
  </head>

 