<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Tour;

class LoginController extends Controller
{
    //
    
    public function index(){
        return view('auth.index');
    }
    
    
    public function customLogin(Request $req){
        $auth = Auth::user();
       
        $req->validate([
            'contact_email' => 'required',
            'password' => 'required',
        ]);
        $credentials = $req->only('contact_email', 'password');
      
        if (Auth::attempt($credentials)) {
          
           
            return redirect()->route('home')->with([
                'message' => 'Your logged in successfully',
                'alert-type' => 'success'
            ]);
            
        }
  
        return redirect("/login")->withSuccess('Login details are not valid');
       
    }

    public function home()
    {
   
        if(Auth::check()){
            $tours = Tour::where("status",46)->get();
            return view("home.tour.index",compact("tours"));
        }
  
        return redirect("/login")->withSuccess('You are not allowed to access');
    }

    
}
